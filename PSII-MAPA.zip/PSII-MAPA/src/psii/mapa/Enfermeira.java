
package psii.mapa;

/** @author uendel
 */
public class Enfermeira extends Envolvidos{
    
}

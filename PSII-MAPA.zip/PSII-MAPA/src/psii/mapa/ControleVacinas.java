
package psii.mapa;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Scanner;

/** @author Uendel
 */
public class ControleVacinas {
    public static void main(String[] args) throws ParseException{
       
        
        String opcao = "";
        
        Cidadao cidadaoVacinado = new Cidadao();
        
        Enfermeira enfermeira = new Enfermeira();
        
        Scanner ler = new Scanner(System.in);
        
        System.out.println("Informe o Nome da Enfermeira:  "  );
        String nomeEnfermeira = ler.nextLine();
        enfermeira.setNome(nomeEnfermeira);
        System.out.println("Nome da enfermeira Aplicadora: "+enfermeira.getNome());
         
        System.out.println("Informe o CPF da enfermeira:  ");
        String cpfEnfermeira = ler.nextLine();
        enfermeira.setCPF(cpfEnfermeira);
        System.out.println("Cpf da Enfermeira Aplicadora:  "+enfermeira.getCPF());
        System.out.println("");
        
        
        System.out.println("--------------------------------------");
        
        
        do{
            System.out.println("Selecione as opções abaixo:");
            System.out.println("1- Vacinar Cidadão");
            System.out.println("2- Listar Cidadão");
            System.out.println("3- Sair");
            
            opcao = ler.nextLine();
        
        
        switch(opcao){
             case "1": 
  
                 System.out.println("Informe o Nome do Cidadão: ");
                 String nomeCidadao = ler.nextLine();
                 cidadaoVacinado.setNome(nomeCidadao);
                 
                 System.out.println("Informe CPF do Cidadão:  ");
                 String cpfCidadao = ler.nextLine();
                 cidadaoVacinado.setCPF(cpfCidadao);
                 System.out.println("");
                  
                 
                 System.out.println("Informe data da 1@ dose (dia/mês/ano): ");
                 String dtInformada1 = ler.nextLine();
                 cidadaoVacinado.setDataDose1(dtInformada1);
                 System.out.println("");
                 //formatação para o padrão pedido
                 String padrao = "dd/MM/yy";
                 SimpleDateFormat formatoDataSimples = new SimpleDateFormat(padrao); 
                 //formatação de String para Calendar
                 Calendar dataD1 = Calendar.getInstance();
                 dataD1.setTime(formatoDataSimples.parse(dtInformada1));
                 
                 
                 System.out.println("Informe data da 2@ dose (dia/mês/ano): ");
                 String dtInformada2 = ler.nextLine();
                 cidadaoVacinado.setDataDose2(dtInformada2);
                 Calendar dataD2 = Calendar.getInstance();
                 dataD2.setTime(formatoDataSimples.parse(dtInformada2));
                 
                 dataD1.add(Calendar.MONTH, 4);
                 
                 if (dataD1.after(dataD2)) {
                     System.out.println("Segunda dose deve ser aplicada 04 meses após a primeira!!");                     
                     break;
                 } else {
                  System.out.println("");
                 }
                
                 
                 System.out.println("Informe data da 3@ dose (dia/mês/ano): ");
                 String dtInformada3 = ler.nextLine();
                 cidadaoVacinado.setDataDose3(dtInformada3);
                 Calendar dataD3 = Calendar.getInstance();
                 dataD3.setTime(formatoDataSimples.parse(dtInformada3));
                 
                 dataD2.add(Calendar.MONTH, 4);
                 
                 if (dataD2.after(dataD3)) {
                     System.out.println("Terceira dose deve ser aplicada 04 meses após a segunda!!");                     
                     break;
                 } else {
                  System.out.println("");
                 }
                 
                 
                 System.out.println("Informe data da 4@ dose (dia/mês/ano): ");
                 String dtInformada4 = ler.nextLine();
                 cidadaoVacinado.setDataDose4(dtInformada4);
                 Calendar dataD4 = Calendar.getInstance();
                 dataD4.setTime(formatoDataSimples.parse(dtInformada4));
                 
                 dataD3.add(Calendar.MONTH, 4);
                 
                 if (dataD3.after(dataD4)) {
                     System.out.println("Quarta dose deve ser aplicada 04 meses após a terceira!!");                    
                     break;
                 } else {
                  System.out.println("");
                 }
                 
                 
                 break;
                 
             case "2": 
                 System.out.println("2-Listar");
                 System.out.println("Nome: "+cidadaoVacinado.getNome());
                 System.out.println("CPF:  "+cidadaoVacinado.getCPF());
                 System.out.println("1 dose: "+cidadaoVacinado.getDataDose1());
                 System.out.println("2 dose: "+cidadaoVacinado.getDataDose2());
                 System.out.println("3 dose: "+cidadaoVacinado.getDataDose3());
                 System.out.println("4 dose: "+cidadaoVacinado.getDataDose4());
                 
                 break;
                 
             case "3":
                 System.exit(0);
                 break;
                 
            default:
                System.out.println("opção invalida!!!");
        }
        } while (!opcao.equals("3")); 
        
        }
        }
    

        


    
                
            
       
        
    


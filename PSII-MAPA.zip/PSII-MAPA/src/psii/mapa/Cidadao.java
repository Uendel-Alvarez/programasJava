
package psii.mapa;

/**
 @author Uendel Alvarez da Silva - Bacharelado Em Engenharia de Software
 * RA 20134745-5
 */
public class Cidadao extends Envolvidos{
    String dataDose1;
    String dataDose2;
    String dataDose3;
    String dataDose4;

    public String getDataDose1() {
        return dataDose1;
    }

    public void setDataDose1(String dataDose1) {
        this.dataDose1 = dataDose1;
    }

    public String getDataDose2() {
        return dataDose2;
    }

    public void setDataDose2(String dataDose2) {
        this.dataDose2 = dataDose2;
    }

    public String getDataDose3() {
        return dataDose3;
    }

    public void setDataDose3(String dataDose3) {
        this.dataDose3 = dataDose3;
    }

    public String getDataDose4() {
        return dataDose4;
    }

    public void setDataDose4(String dataDose4) {
        this.dataDose4 = dataDose4;
    }

   
}
   
